// #include "Struct_Alum.h"

void Print_Alumno(struct Alumno *);