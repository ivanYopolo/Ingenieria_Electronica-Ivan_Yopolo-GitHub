// #include "Struct_Alum.h"

void Init_Alumno(struct Alumno *);
