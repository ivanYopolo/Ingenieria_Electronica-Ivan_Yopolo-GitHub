#define tamString 40

struct Alumno{
	char Nombre[tamString];
	char Apellido[tamString];
	int Edad;
	double Legajo;
	int P1;
	int P2;
	int Final;
};

